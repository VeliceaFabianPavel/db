import java.util.Comparator;
import java.util.List;

public class Sorter {

    public static void sortByPriceDescending(List<Cars> cars) {
        cars.sort(Comparator.comparingDouble(Cars::getPRICE).reversed());
    }
}
