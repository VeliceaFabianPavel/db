import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static List<Cars> readCarsFromCSV(String filename) {
        List<Cars> carsList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            br.readLine(); // Skip header line
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                int id = Integer.parseInt(values[0].trim());
                String make = values[1].trim();
                String model = values[2].trim();
                int year = Integer.parseInt(values[3].trim());
                String color = values[4].trim();
                int noSeats = Integer.parseInt(values[5].trim());
                int mileage = Integer.parseInt(values[6].trim());
                double price = Double.parseDouble(values[7].trim());
                String status = values[8].trim();

                if (mileage <= 15000) { // Filter cars with mileage less than or equal to 15000
                    carsList.add(new Cars(id, make, model, year, color, noSeats, mileage, price, status));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return carsList;
    }

    public static void main(String[] args) {
        List<Cars> carsList = readCarsFromCSV("JavaExam\\cars.csv");

        Sorter.sortByPriceDescending(carsList);
        for (Cars car : carsList) {
            System.out.println(car);
        }
    }
}
