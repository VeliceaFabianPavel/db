public class Cars {
    public Cars(int ID, String MAKE, String MODEL, int YEAR, String COLOR, int NO_SEATS, int MILEAGE, double PRICE, String STATUS) {
        this.ID = ID;
        this.MAKE = MAKE;
        this.MODEL = MODEL;
        this.YEAR = YEAR;
        this.COLOR = COLOR;
        this.NO_SEATS = NO_SEATS;
        this.MILEAGE = MILEAGE;
        this.PRICE = PRICE;
        this.STATUS = STATUS;
    }

    private int ID;
    private String MAKE;
    private String MODEL;
    private int YEAR;
    private String COLOR;
    private int NO_SEATS;
    private int MILEAGE;
    private double PRICE;
    private String STATUS;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getMAKE() {
        return MAKE;
    }

    public void setMAKE(String MAKE) {
        this.MAKE = MAKE;
    }

    public String getMODEL() {
        return MODEL;
    }

    public void setMODEL(String MODEL) {
        this.MODEL = MODEL;
    }

    public int getYEAR() {
        return YEAR;
    }

    public void setYEAR(int YEAR) {
        this.YEAR = YEAR;
    }

    public String getCOLOR() {
        return COLOR;
    }

    public void setCOLOR(String COLOR) {
        this.COLOR = COLOR;
    }

    public int getNO_SEATS() {
        return NO_SEATS;
    }

    public void setNO_SEATS(int NO_SEATS) {
        this.NO_SEATS = NO_SEATS;
    }

    public int getMILEAGE() {
        return MILEAGE;
    }

    public void setMILEAGE(int MILEAGE) {
        this.MILEAGE = MILEAGE;
    }

    public double getPRICE() {
        return PRICE;
    }

    public void setPRICE(double PRICE) {
        this.PRICE = PRICE;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    @Override
    public String toString() {
        return "Cars{" +
                "ID=" + ID +
                ", MAKE='" + MAKE + '\'' +
                ", MODEL='" + MODEL + '\'' +
                ", YEAR=" + YEAR +
                ", COLOR='" + COLOR + '\'' +
                ", NO_SEATS=" + NO_SEATS +
                ", MILEAGE=" + MILEAGE +
                ", PRICE=" + PRICE +
                ", STATUS='" + STATUS + '\'' +
                '}';
    }
}
